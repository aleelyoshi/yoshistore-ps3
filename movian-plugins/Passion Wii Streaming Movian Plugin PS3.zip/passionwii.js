(function(plugin) {
    // Plugin de Passion Wii Streaming para Movian (PlayStation 3)
    
    // Incluir dependencia HTTP de Movian
    var http = require('movian/http');
    // Permitir enrutamiento de URLs
    plugin.config.URIRouting = true;
    // Inicializar ID de plugin
    var pluginId = "passionwii"
    // Inicializar directorio de imagenes
    var imgDir = plugin.path + "img/";
    // Inicializar logo de Passion Wii Streaming
    var pwsLogo = imgDir + "logo.png";
    // Inicializar URLs de listas de Passion Wii Streaming
    // // Streaming General
    var urlStreamingGeneral = "http://passionstreamingwii.myartsonline.com/Passion%20Wii%20Streaming";
    // // Streaming Zona Kids
    var urlStreamingZonaKids = "http://passionstreamingwii.myartsonline.com/Zona%20Kids";
    // // Novedades en el Streaming
    var urlNovedadesEnElStreaming = "http://passionstreamingwii.myartsonline.com/Novedades/news";
    
    // Agregar Passion Wii Streaming al menu principal de Movian
    plugin.createService("Passion Wii Streaming", pluginId + ":start", "video", true, pwsLogo);
    
    // Inicializar menu de Passion Wii Streaming
    plugin.addURI(pluginId + ":start", function(page) {
        page.type = "directory";
        page.metadata.title = "Passion Wii Streaming";
        page.metadata.background = imgDir + "bg.png";
        // Opciones de Passion Wii Streaming
        page.appendItem(pluginId + ":parse:" + encodeURIComponent(urlStreamingGeneral) + ":" + encodeURIComponent("Streaming General"), "video", {
            title: "Streaming General",
            icon: imgDir + "StreamingGeneral.png"
        });
        page.appendItem(pluginId + ":parse:" + encodeURIComponent(urlStreamingZonaKids) + ":" + encodeURIComponent("Streaming Zona Kids"), "video", {
            title: "Streaming Zona Kids",
            icon: imgDir + "StreamingZonaKids.png"
        });
        page.appendItem(pluginId + ":parse:" + encodeURIComponent(urlNovedadesEnElStreaming) + ":" + encodeURIComponent("Novedades en el Streaming"), "video", {
            title: "Novedades en el Streaming",
            icon: imgDir + "NovedadesEnElStreaming.png"
        });
    });

    // Procesador de listas compatible con M3U y el formato propietario de WiiMC
    plugin.addURI(pluginId + ":parse:(.*):(.*)", function(page, listUrl, listTitle) {
        page.type = "directory";
        page.metadata.title = decodeURIComponent(listTitle);
        page.metadata.background = imgDir + "bg.png";
        page.loading = true
        var response = http.request(decodeURIComponent(listUrl), { method: 'GET' });
        var lines = response.toString().split(/\r\n|\r|\n/);
        
        var currentItem = {};
        var format = "UNDEF";
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            // Comprobar el formato de lista
            if (format == "UNDEF") {
                if (lines[i].indexOf("#EXTM3U") === 0) {
                    // Si el formato de lista es M3U, procesar M3U
                    format = "M3U";
                } else if (lines[i] == '#') {
                    // Si el formato de lista es el formato propietario de WiiMC, procesar el formato propietario de WiiMC
                    format = "WIIMC";
                }
            }
            
            // Procesador de listas en el formato propietario de WiiMC
            if (format == "WIIMC") {
                if (line.indexOf("type=") === 0 && format == "WIIMC") {
                    // Identificador de tipo de elemento, ignorable
                    showtime.print("Identificador de tipo de elemento detectado, ignorando...");
                } else if (line.indexOf("name=") !== -1 && format == "WIIMC") {
                    currentItem.title = line.replace('name=', '');
                } else if (line.indexOf("thumb=") !== -1 && format == "WIIMC") {
                    if (line.replace("thumb=", "").length > 0) {
                        currentItem.logo = line.replace("thumb=", "");
                    } else {
                        currentItem.logo = imgDir + "nocover.png";
                    }
                } else if (line.indexOf("xml=") !== -1 && format == "WIIMC") {
                    // Archivo XML de metadatos, ignorable
                    showtime.print("Archivo XML de metadatos de WiiMC detectado, ignorando...");
                } else if (line.indexOf("URL=") !== -1 && format == "WIIMC") {
                    currentItem.url = line.replace("URL=", "");
                    var lowercaseUrl = currentItem.url.toLowerCase()
                    var isVideo = lowercaseUrl.indexOf('.mp4') !== -1 || lowercaseUrl.indexOf('.mkv') !== -1 || lowercaseUrl.indexOf('.flv') !== -1 || lowercaseUrl.indexOf('.m4v') !== -1 || lowercaseUrl.indexOf('.avi') !== -1 || lowercaseUrl.indexOf('.mov') !== -1 || lowercaseUrl.indexOf('.ogv') !== -1 || lowercaseUrl.indexOf('.mpd') !== -1 || lowercaseUrl.indexOf('.ts') !== -1 || lowercaseUrl.indexOf('clarodrive.com') !== -1;
                    var isAudio = lowercaseUrl.indexOf('.aac') !== -1 || lowercaseUrl.indexOf('.flac') !== -1 || lowercaseUrl.indexOf('.m4a') !== -1 || lowercaseUrl.indexOf('.mp3') !== -1 || lowercaseUrl.indexOf('.ogg') !== -1 || lowercaseUrl.indexOf('.wav') !== -1 || lowercaseUrl.indexOf('.wma') !== -1;
                    if (currentItem.logo == imgDir + "nocover.png") {
                        if (isVideo || isAudio) {
                            currentItem.logo = imgDir + "nocover.png"
                        } else {
                            currentItem.logo = imgDir + "nocover_fol.png"
                        }
                    }
                    var targetUri = pluginId + ":route:" + encodeURIComponent(currentItem.url) + ":" + encodeURIComponent(currentItem.title);
                    page.appendItem(targetUri, "video", {
                        title: currentItem.title,
                        icon: currentItem.logo,
                        noResume: true,
                        start_time: 0
                    });
                    currentItem = {};
                }
            }
            
            // Procesador de listas M3U
            if (format == "M3U") {
                if (line.indexOf("#EXTINF:") === 0 && format == "M3U") {
                    var logoMatch = line.match(/tvg-logo="([^"]+)"/);
                    var nameMatch = line.match(/,(.+)$/);
                    currentItem.logo = logoMatch ? logoMatch[1] : imgDir + "nocover.png";
                    currentItem.title = nameMatch ? nameMatch[1].trim() : "Desconocido";
                } else if (line.length > 0 && line.indexOf('#') !== 0 && format == "M3U") {
                    currentItem.url = line;
                    var lowercaseUrl = currentItem.url.toLowerCase()
                    var isVideo = lowercaseUrl.indexOf('.mp4') !== -1 || lowercaseUrl.indexOf('.mkv') !== -1 || lowercaseUrl.indexOf('.flv') !== -1 || lowercaseUrl.indexOf('.m4v') !== -1 || lowercaseUrl.indexOf('.avi') !== -1 || lowercaseUrl.indexOf('.mov') !== -1 || lowercaseUrl.indexOf('.ogv') !== -1 || lowercaseUrl.indexOf('.mpd') !== -1 || lowercaseUrl.indexOf('.ts') !== -1 || lowercaseUrl.indexOf('clarodrive.com') !== -1;
                    var isAudio = lowercaseUrl.indexOf('.aac') !== -1 || lowercaseUrl.indexOf('.flac') !== -1 || lowercaseUrl.indexOf('.m4a') !== -1 || lowercaseUrl.indexOf('.mp3') !== -1 || lowercaseUrl.indexOf('.ogg') !== -1 || lowercaseUrl.indexOf('.wav') !== -1 || lowercaseUrl.indexOf('.wma') !== -1;
                    if (currentItem.logo == imgDir + "nocover.png") {
                        if (isVideo || isAudio) {
                            currentItem.logo = imgDir + "nocover.png"
                        } else {
                            currentItem.logo = imgDir + "nocover_fol.png"
                        }
                    }
                    var targetUri = pluginId + ":route:" + encodeURIComponent(currentItem.url) + ":" + encodeURIComponent(currentItem.title);
                    page.appendItem(targetUri, "video", {
                        title: currentItem.title,
                        icon: currentItem.logo,
                        noResume: true,
                        start_time: 0
                    });
                    currentItem = {}; 
                }
            }
        }
        page.loading = false
    });

    // Verificador para comprobar si el elemento es un video o una lista
    plugin.addURI(pluginId + ":route:(.*):(.*)", function(page, targetUrl, targetTitle) {
        var decUrl = decodeURIComponent(targetUrl);
        var decTitle = decodeURIComponent(targetTitle);
        var lowercaseUrl = decUrl.toLowerCase();
        var isVideo = lowercaseUrl.indexOf('.mp4') !== -1 || lowercaseUrl.indexOf('.mkv') !== -1 || lowercaseUrl.indexOf('.flv') !== -1 || lowercaseUrl.indexOf('.m4v') !== -1 || lowercaseUrl.indexOf('.avi') !== -1 || lowercaseUrl.indexOf('.mov') !== -1 || lowercaseUrl.indexOf('.ogv') !== -1 || lowercaseUrl.indexOf('.mpd') !== -1 || lowercaseUrl.indexOf('.ts') !== -1 || lowercaseUrl.indexOf('clarodrive.com') !== -1;
        var isAudio = lowercaseUrl.indexOf('.aac') !== -1 || lowercaseUrl.indexOf('.flac') !== -1 || lowercaseUrl.indexOf('.m4a') !== -1 || lowercaseUrl.indexOf('.mp3') !== -1 || lowercaseUrl.indexOf('.ogg') !== -1 || lowercaseUrl.indexOf('.wav') !== -1 || lowercaseUrl.indexOf('.wma') !== -1;
        if (isVideo || isAudio) {
            page.redirect(decUrl);
        } else {
            page.redirect(pluginId + ":parse:" + encodeURIComponent(decUrl) + ":" + encodeURIComponent(decTitle));
        }
    });

})(this);
